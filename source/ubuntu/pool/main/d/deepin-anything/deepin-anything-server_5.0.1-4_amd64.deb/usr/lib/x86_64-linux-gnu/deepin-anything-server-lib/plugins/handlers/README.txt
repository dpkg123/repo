Plugin IID: "com.deepin.anything.server.DASFactoryInterface_iid"
