mobile-broadband-provider-info XML 配置解析库, 默认配置文件是
/usr/share/mobile-broadband-provider-info/serviceproviders.xml, 可以提
供各国家和地区的移动运营商信息(GSM/CDMA).
