package glib

import "C"
import "unsafe"

//export _GLib_go_callback_cleanup
func _GLib_go_callback_cleanup(unsafe.Pointer) {
}
